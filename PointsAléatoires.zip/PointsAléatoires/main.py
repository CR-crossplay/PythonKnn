import pygame
from pygame.locals import *
import numpy as np
from random import randint
def read_data(url:str)->dict:
    with open(url,"r",encoding='utf-8') as f: return f.readlines()

conf={e.split(":",1)[0]:e.split(":",1)[1] for e in read_data("conf.ini")}
w_x=1366
w_y=768
try:
    w_x=int(conf["w_x"])
    w_y=int(conf["w_y"])
except:
    print("Conseil : Vous pouvez changer la taille de la feunêtre dans config.ini")
pygame.init()
window=pygame.display.set_mode((w_x,w_y))
bg_color=(18,18,18)
alea=randint(1,100000)
print(f"Seed : {alea}")
rand=np.random.RandomState(alea)#Besoin pour créer l'array random
print("""
conf.ini permet de :
modifier le nombre de points (des différentes couleurs)
modifier la taille de la feunêtre (flexible)
""")
X=rand.rand(10,2)
font = pygame.font.Font('Roboto-Regular.ttf', 32) #Include roboto (meilleur police ever)

#=== Création de l'array numpy ===#
try:
    conf["points_rouges"] = int(conf["points_rouges"])
    nbr=conf["points_rouges"]
except:
    print("Erreur : points_rouges n'est pas défini ou alors n'est pas un nombre entier.")
    quit(1)
try :
    conf["points_bleus"]=int(conf["points_bleus"])
    nbb=conf["points_bleus"]
except:
    print("Erreur : points_bleus n'est pas défini ou alors n'est pas un nombre entier.")

try :
    conf["points_blancs"]=int(conf["points_blancs"])
    nbbla=conf["points_blancs"]
except:
    print("Erreur : points_blancs n'est pas défini ou alors n'est pas un nombre entier.")
#nb+=conf["points_colorn"]
conf["arr_rouges"]=rand.rand(nbr,2)
conf["arr_bleus"]=rand.rand(nbb,2)
conf["arr_blancs"]=rand.rand(nbbla,2)
#===                           ===#
#===Tracer de la figure avec matplotlib===#
import matplotlib
matplotlib.use("Agg")
import matplotlib.backends.backend_agg as agg
import pylab
import numpy as np
import matplotlib.style

fig = pylab.figure(figsize=[4,4], # Inches
                   dpi=100,        # 100 dots per inch, so the resulting buffer is 400x400 pixels
                   )
plt = fig.gca()
plt.scatter(conf["arr_rouges"][:,0],conf["arr_rouges"][:,1],c="red",alpha=0.8)
plt.scatter(conf["arr_blancs"][:,0],conf["arr_blancs"][:,1],c="white")
plt.scatter(conf["arr_bleus"][:,0],conf["arr_bleus"][:,1],c="blue",alpha=0.8)
plt.set_facecolor((18/255,18/255,18/255))
canvas = agg.FigureCanvasAgg(fig)
canvas.draw()
renderer = canvas.get_renderer()
conf["raw"]= renderer.tostring_rgb()
#===                                   ===#


def draw_voisins(K):
    import matplotlib.style

    fig = pylab.figure(figsize=[4, 4],  # Inches
                       dpi=100,  # 100 dots per inch, so the resulting buffer is 400x400 pixels
                       )
    plt = fig.gca()

    rand = np.random.RandomState(42)
    arr_bleus = conf["arr_bleus"]
    arr_red = conf["arr_rouges"]
    arr_blancs = conf["arr_blancs"]

    X = np.concatenate((arr_bleus, arr_blancs, arr_red))
    for k in range(X.shape[0]):
        if X[k, :] in arr_blancs:
            plt.scatter(X[k, 0], X[k, 1], c="w")
        elif X[k, :] in arr_bleus:
            plt.scatter(X[k, 0], X[k, 1], c="blue")
        elif X[k, :] in arr_red:
            plt.scatter(X[k, 0], X[k, 1], c="red")
    differences = (X[:, np.newaxis] - X[np.newaxis,
                                      :]) ** 2  # Différence au carré entre les points, shape (10,10,2) (avec aggregation)
    distance = np.sum(differences,
                      -1)  # On fait la somme des différences pour avoir la distance entre les points, shape (10,10)
    K = 1  # 1 voisin pour chaque points
    nearest = np.argpartition(distance, K + 1, axis=1)
    for i in range(X.shape[0]):
        for j in nearest[i, :K + 1]:
            if X[i] in arr_blancs:
                ok=False
                while not ok:
                    if X[j] in arr_red:
                        plt.scatter(X[i, 0], X[i, 1], color="red")
                        conf['points_rouges']+=.5
                        conf['points_blancs']-=.5
                        ok=True
                    elif X[j] in arr_bleus:
                        plt.scatter(X[i, 0], X[i, 1], color="blue")
                        conf['points_bleus']+=.5
                        conf['points_blancs']-=.5
                        ok=True
                    else:j+=1
                #plt.plot(*zip(X[j], X[i]), color="w")
            else:
                plt.plot(*zip(X[j], X[i]), color="black")

    plt.set_facecolor((18 / 255, 18 / 255, 18 / 255))
    canvas = agg.FigureCanvasAgg(fig)
    canvas.draw()
    renderer = canvas.get_renderer()
    conf["raw"]= renderer.tostring_rgb()



loop=True
while loop:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            loop=False
            pygame.quit()
            quit(0)
        if event.type == pygame.MOUSEBUTTONUP:
            if "txtButton" in locals():
                x_left = w_x - txtButton.get_width()
                x_right = w_x
                y_top = infoAll.get_height() + infoRed.get_height() + infoWhite.get_height()+ infoBlue.get_height()+txtButton.get_height() / 2
                y_bottom = infoAll.get_height() + infoRed.get_height() + infoWhite.get_height()+ infoBlue.get_height()+ txtButton.get_height() * 1.5
                if x_left < mouse[0] < x_right and y_top < mouse[1] < y_bottom:
                    draw_voisins(2)



    infoAll = font.render(f"Nombre de points : {conf['points_rouges']+conf['points_bleus']+conf['arr_blancs'].shape[0]}", True, (255, 215, 0), bg_color)
    infoAllRect = infoAll.get_rect()
    infoAllRect.center = (w_x-infoAll.get_width()/2,infoAll.get_height())
    infoRed=font.render(f"Nombre de points rouges : {conf['points_rouges']}",True,(139,0,0),bg_color)
    infoRedRect=infoRed.get_rect()
    infoRedRect.center=(w_x-infoRed.get_width()/2,infoRed.get_height()+infoAll.get_height())
    window.fill(bg_color)
    infoBlue=font.render(f"Nombre de points bleus : {conf['points_bleus']}",True,(139,0,0),bg_color)
    infoBlueRect=infoBlue.get_rect()
    infoBlueRect.center=(w_x-infoBlue.get_width()/2,infoBlue.get_height()+infoAll.get_height()+infoRed.get_height())


    size = canvas.get_width_height()
    surf = pygame.image.fromstring(conf["raw"], size, "RGB")
    window.blit(surf, (0, 0))
    window.blit(infoAll,infoAllRect)
    window.blit(infoBlue,infoBlueRect)
    window.blit(infoRed,infoRedRect)
    #===Bouton "dessiner"===
    mouse = pygame.mouse.get_pos()
    try:
        x_left = w_x - txtButton.get_width()
        x_right = w_x
        y_top = infoAll.get_height() + infoRed.get_height() + infoWhite.get_height() + infoBlue.get_height() + txtButton.get_height() / 2
        y_bottom = infoAll.get_height() + infoRed.get_height() + infoWhite.get_height() + infoBlue.get_height() + txtButton.get_height() * 1.5
        if x_left<mouse[0]<x_right and y_top<mouse[1]<y_bottom:
            txtButton=font.render("Dessiner",True,(255,215,0),(2,2,2))
        else:txtButton=font.render("Dessiner",True,(255,255,255),(39,39,39))
    except: pass #On est à la première itération
    if not "txtButton" in locals():
        txtButton = font.render("Dessiner", True, (255, 255, 255), (39, 39, 39))
        txtButtonRect=txtButton.get_rect()


    infoWhite=font.render(f"Nombre de points blancs : {conf['points_blancs']} ",True,(255,255,255),bg_color)
    infoWhiteRect=infoWhite.get_rect()
    infoWhiteRect.center=(w_x-infoWhite.get_width()/2,infoBlue.get_height()+infoAll.get_height()+infoRed.get_height()+txtButton.get_height())
    window.blit(infoWhite, infoWhiteRect)
    txtButtonRect.center = (w_x - txtButton.get_width() / 2,
                            infoWhite.get_height()+infoAll.get_height() + infoBlue.get_height() + infoRed.get_height() + txtButton.get_height())
    window.blit(txtButton, txtButtonRect)
    #===                 ===#



    pygame.display.flip()
    pygame.display.update()